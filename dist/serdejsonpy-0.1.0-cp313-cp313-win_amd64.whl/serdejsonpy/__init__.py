from .serdejsonpy import *

__doc__ = serdejsonpy.__doc__
if hasattr(serdejsonpy, "__all__"):
    __all__ = serdejsonpy.__all__